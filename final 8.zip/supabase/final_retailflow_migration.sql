-- Final RetailFlow safe database migration
-- Purpose:
--   Upgrade the existing live Supabase database to the final RetailFlow architecture
--   without recreating existing tables, destroying data, or reintroducing banned
--   competition or automated task-generation features.
--
-- IMPORTANT:
--   - This is a migration, not a full setup script.
--   - It must be safe to run against an existing database with current data.
--   - It only adds missing final-state objects and removes stale competition/automation artifacts.

BEGIN;

-- -----------------------------------------------------------------------------
-- 0) Safety helpers
-- -----------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- -----------------------------------------------------------------------------
-- 1) Remove stale competition objects only if they exist
-- -----------------------------------------------------------------------------
-- Remove stale competition data tables and supporting functions. Do not touch
-- points/badges/task reward logic.
DO $$
DECLARE
  rec record;
BEGIN
  -- Drop competition-related table objects if present.
  DROP TABLE IF EXISTS public.branch_leaderboard_entries CASCADE;
  DROP TABLE IF EXISTS public.competition_products CASCADE;
  DROP TABLE IF EXISTS public.competition_branches CASCADE;
  DROP TABLE IF EXISTS public.competitions CASCADE;

  -- Drop competition / leaderboard-related functions if present.
  FOR rec IN
    SELECT p.oid, p.proname
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND (
        p.proname ILIKE '%competition%' OR
        p.proname ILIKE '%leaderboard%' OR
        p.proname ILIKE '%ranking%'
      )
  LOOP
    EXECUTE format(
      'DROP FUNCTION IF EXISTS public.%I(%s);',
      rec.proname,
      pg_get_function_identity_arguments(rec.oid)
    );
  END LOOP;
END $$;

-- Remove stale cron jobs for competition/leaderboard automation, if pg_cron is enabled.
-- This is intentionally guarded because cron.job is a privileged catalog table in many
-- Supabase environments and may be inaccessible to the current role.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_cron') THEN
    BEGIN
      DELETE FROM cron.job
      WHERE jobname ILIKE '%competition%'
         OR jobname ILIKE '%leaderboard%'
         OR jobname ILIKE '%ranking%';
    EXCEPTION WHEN insufficient_privilege THEN
      RAISE NOTICE 'Skipping competition cron cleanup: insufficient privileges for cron.job';
    END;
  END IF;
END $$;

-- -----------------------------------------------------------------------------
-- 2) Remove stale task automation database objects only if they exist
-- -----------------------------------------------------------------------------
-- Do NOT remove tasks, task_assignments, task_completions, or points system.
DO $$
DECLARE
  rec record;
BEGIN
  FOR rec IN
    SELECT p.oid, p.proname
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND (
        p.proname ILIKE '%task%' AND (
          p.proname ILIKE '%automation%' OR
          p.proname ILIKE '%generate%' OR
          p.proname ILIKE '%scheduler%' OR
          p.proname ILIKE '%schedule%' OR
          p.proname ILIKE '%recurr%' OR
          p.proname ILIKE '%cron%'
        )
      )
  LOOP
    EXECUTE format(
      'DROP FUNCTION IF EXISTS public.%I(%s);',
      rec.proname,
      pg_get_function_identity_arguments(rec.oid)
    );
  END LOOP;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_cron') THEN
    BEGIN
      DELETE FROM cron.job
      WHERE jobname ILIKE '%task%'
         AND (
           jobname ILIKE '%automation%' OR
           jobname ILIKE '%generate%' OR
           jobname ILIKE '%schedule%' OR
           jobname ILIKE '%recurr%' OR
           jobname ILIKE '%cron%'
         );
    EXCEPTION WHEN insufficient_privilege THEN
      RAISE NOTICE 'Skipping task automation cron cleanup: insufficient privileges for cron.job';
    END;
  END IF;
END $$;

-- -----------------------------------------------------------------------------
-- 3) Shared trigger helper: safe for existing DBs
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- -----------------------------------------------------------------------------
-- 4) Fix duplicate trigger problem safely
-- -----------------------------------------------------------------------------
DO $$
BEGIN
  IF to_regclass('public.issue_reports') IS NOT NULL THEN
    DROP TRIGGER IF EXISTS issue_reports_touch_updated_at ON public.issue_reports;
  END IF;

  IF to_regclass('public.leave_requests') IS NOT NULL THEN
    DROP TRIGGER IF EXISTS leave_requests_touch_updated_at ON public.leave_requests;
  END IF;
END $$;

CREATE TRIGGER issue_reports_touch_updated_at
BEFORE UPDATE ON public.issue_reports
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER leave_requests_touch_updated_at
BEFORE UPDATE ON public.leave_requests
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- -----------------------------------------------------------------------------
-- 5) Normalize products for price management
-- -----------------------------------------------------------------------------
-- The live database may still be on the older schema where products do not have
-- a current_price column. Price management depends on this column existing.
ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS current_price numeric(14,2) NOT NULL DEFAULT 0;

ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS updated_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL;

ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS updated_at timestamptz;

ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true;

ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();

-- If an older legacy column exists, migrate it into current_price without data loss.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'products'
      AND column_name = 'unit_price'
  ) THEN
    UPDATE public.products
    SET current_price = COALESCE(current_price, unit_price, 0)
    WHERE current_price IS NULL OR current_price = 0;
  END IF;
END $$;

ALTER TABLE public.products DROP COLUMN IF EXISTS unit_price;
ALTER TABLE public.products ALTER COLUMN current_price SET DEFAULT 0;
ALTER TABLE public.products ALTER COLUMN current_price SET NOT NULL;

-- -----------------------------------------------------------------------------
-- 6) Create attendance table if it does not exist
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  branch_id uuid NOT NULL REFERENCES public.branches(id) ON DELETE CASCADE,
  attendance_date date NOT NULL,
  check_in_time timestamptz,
  check_out_time timestamptz,
  status text NOT NULL DEFAULT 'present'
    CHECK (status IN ('present', 'late', 'absent', 'half_day')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (employee_id, attendance_date)
);

CREATE INDEX IF NOT EXISTS idx_attendance_employee_date
  ON public.attendance(employee_id, attendance_date DESC);
CREATE INDEX IF NOT EXISTS idx_attendance_branch_date
  ON public.attendance(branch_id, attendance_date DESC);

ALTER TABLE public.attendance ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "attendance_select_own" ON public.attendance;
DROP POLICY IF EXISTS "attendance_select_branch" ON public.attendance;
DROP POLICY IF EXISTS "attendance_insert_own" ON public.attendance;
DROP POLICY IF EXISTS "attendance_update_own" ON public.attendance;
DROP POLICY IF EXISTS "attendance_admin_full" ON public.attendance;

CREATE POLICY "attendance_select_own"
  ON public.attendance FOR SELECT
  USING (employee_id = auth.uid());

CREATE POLICY "attendance_select_branch"
  ON public.attendance FOR SELECT
  USING (
    public.get_my_role() = 'admin'
    OR (
      public.get_my_role() = 'manager'
      AND EXISTS (
        SELECT 1
        FROM public.profiles p
        WHERE p.id = auth.uid()
          AND p.branch_id = public.attendance.branch_id
      )
    )
  );

CREATE POLICY "attendance_insert_own"
  ON public.attendance FOR INSERT
  WITH CHECK (employee_id = auth.uid());

CREATE POLICY "attendance_update_own"
  ON public.attendance FOR UPDATE
  USING (employee_id = auth.uid())
  WITH CHECK (employee_id = auth.uid());

CREATE POLICY "attendance_admin_full"
  ON public.attendance FOR ALL
  USING (public.get_my_role() = 'admin')
  WITH CHECK (public.get_my_role() = 'admin');

DO $$
BEGIN
  IF to_regclass('public.attendance') IS NOT NULL THEN
    DROP TRIGGER IF EXISTS attendance_touch_updated_at ON public.attendance;
  END IF;
END $$;

CREATE TRIGGER attendance_touch_updated_at
BEFORE UPDATE ON public.attendance
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- -----------------------------------------------------------------------------
-- 7) Create product_price_history if it does not exist
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.product_price_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  old_price numeric(14,2) DEFAULT 0,
  new_price numeric(14,2) DEFAULT 0,
  updated_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_product_price_history_product_id
  ON public.product_price_history(product_id, updated_at DESC);

CREATE OR REPLACE FUNCTION public.log_product_price_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.current_price IS DISTINCT FROM OLD.current_price THEN
    INSERT INTO public.product_price_history (
      product_id,
      old_price,
      new_price,
      updated_by,
      updated_at
    )
    VALUES (
      NEW.id,
      COALESCE(OLD.current_price, 0),
      COALESCE(NEW.current_price, 0),
      auth.uid(),
      now()
    );
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS products_price_history_log ON public.products;
CREATE TRIGGER products_price_history_log
BEFORE UPDATE ON public.products
FOR EACH ROW
WHEN (NEW.current_price IS DISTINCT FROM OLD.current_price)
EXECUTE FUNCTION public.log_product_price_change();

ALTER TABLE public.product_price_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "product_price_history_select_auth" ON public.product_price_history;
DROP POLICY IF EXISTS "product_price_history_insert_manager_admin" ON public.product_price_history;
DROP POLICY IF EXISTS "product_price_history_update_manager_admin" ON public.product_price_history;
DROP POLICY IF EXISTS "product_price_history_admin_full" ON public.product_price_history;

CREATE POLICY "product_price_history_select_auth"
  ON public.product_price_history FOR SELECT
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "product_price_history_insert_manager_admin"
  ON public.product_price_history FOR INSERT
  WITH CHECK (public.get_my_role() IN ('manager', 'admin'));

CREATE POLICY "product_price_history_update_manager_admin"
  ON public.product_price_history FOR UPDATE
  USING (public.get_my_role() IN ('manager', 'admin'))
  WITH CHECK (public.get_my_role() IN ('manager', 'admin'));

CREATE POLICY "product_price_history_admin_full"
  ON public.product_price_history FOR ALL
  USING (public.get_my_role() = 'admin')
  WITH CHECK (public.get_my_role() = 'admin');

DO $$
BEGIN
  IF to_regclass('public.product_price_history') IS NOT NULL THEN
    DROP TRIGGER IF EXISTS product_price_history_touch_updated_at ON public.product_price_history;
  END IF;
END $$;

CREATE TRIGGER product_price_history_touch_updated_at
BEFORE UPDATE ON public.product_price_history
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- -----------------------------------------------------------------------------
-- 8) Create task_templates only if missing
-- -----------------------------------------------------------------------------
-- Note: Task templates are reusable definitions only.
-- No automatic generation, scheduler, cron, or recurring task execution.
CREATE TABLE IF NOT EXISTS public.task_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  frequency text NOT NULL DEFAULT 'daily',
  points integer NOT NULL DEFAULT 10 CHECK (points >= 0),
  photo_required boolean NOT NULL DEFAULT false,
  branch_id uuid REFERENCES public.branches(id) ON DELETE SET NULL,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_task_templates_branch_active
  ON public.task_templates(branch_id, is_active, created_at DESC);

ALTER TABLE public.task_templates ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "task_templates_select_auth" ON public.task_templates;
DROP POLICY IF EXISTS "task_templates_insert_manager_admin" ON public.task_templates;
DROP POLICY IF EXISTS "task_templates_update_manager_admin" ON public.task_templates;
DROP POLICY IF EXISTS "task_templates_delete_manager_admin" ON public.task_templates;

CREATE POLICY "task_templates_select_auth"
  ON public.task_templates FOR SELECT
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "task_templates_insert_manager_admin"
  ON public.task_templates FOR INSERT
  WITH CHECK (public.get_my_role() IN ('manager', 'admin'));

CREATE POLICY "task_templates_update_manager_admin"
  ON public.task_templates FOR UPDATE
  USING (public.get_my_role() IN ('manager', 'admin'))
  WITH CHECK (public.get_my_role() IN ('manager', 'admin'));

CREATE POLICY "task_templates_delete_manager_admin"
  ON public.task_templates FOR DELETE
  USING (public.get_my_role() IN ('manager', 'admin'));

DO $$
BEGIN
  IF to_regclass('public.task_templates') IS NOT NULL THEN
    DROP TRIGGER IF EXISTS task_templates_touch_updated_at ON public.task_templates;
  END IF;
END $$;

CREATE TRIGGER task_templates_touch_updated_at
BEFORE UPDATE ON public.task_templates
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- -----------------------------------------------------------------------------
-- 9) Clean up legacy scheduler metadata if present
-- -----------------------------------------------------------------------------
-- The system uses manually created tasks; recurring execution is not part of the
-- final RetailFlow architecture.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_cron') THEN
    BEGIN
      DELETE FROM cron.job
      WHERE jobname ILIKE '%template%'
         OR jobname ILIKE '%automation%'
         OR jobname ILIKE '%generation%'
         OR jobname ILIKE '%scheduler%'
         OR jobname ILIKE '%recurr%';
    EXCEPTION WHEN insufficient_privilege THEN
      RAISE NOTICE 'Skipping legacy scheduler cleanup: insufficient privileges for cron.job';
    END;
  END IF;
END $$;

-- -----------------------------------------------------------------------------
-- 10) Verification queries
-- -----------------------------------------------------------------------------
-- Check tables.
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
  AND table_name IN ('attendance', 'product_price_history', 'task_templates')
ORDER BY table_name;

-- Check RLS state for all required tables.
SELECT schemaname, tablename, rowsecurity
FROM pg_tables
WHERE schemaname = 'public'
  AND tablename IN ('attendance', 'product_price_history', 'task_templates')
ORDER BY tablename;

-- Check policies for all required tables.
SELECT schemaname, tablename, policyname, cmd, roles, qual
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename IN ('attendance', 'product_price_history', 'task_templates')
ORDER BY tablename, policyname;

-- Check cron jobs if pg_cron is installed and the current role has access.
DO $$
DECLARE
  v_count integer := 0;
BEGIN
  IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_cron') THEN
    BEGIN
      SELECT COUNT(*) INTO v_count
      FROM cron.job
      WHERE jobname ILIKE '%competition%'
         OR jobname ILIKE '%leaderboard%'
         OR jobname ILIKE '%ranking%'
         OR jobname ILIKE '%template%'
         OR jobname ILIKE '%automation%'
         OR jobname ILIKE '%generate%'
         OR jobname ILIKE '%recurr%';

      RAISE NOTICE 'Matching cron jobs detected: %', v_count;
    EXCEPTION WHEN insufficient_privilege THEN
      RAISE NOTICE 'Skipping cron verification: insufficient privileges for cron.job';
    END;
  END IF;
END $$;

COMMIT;
